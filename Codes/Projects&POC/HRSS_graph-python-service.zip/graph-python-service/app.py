import azure.functions as func

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

from neo4j import GraphDatabase
import json
import openai
from openai import AzureOpenAI
import os

openai.api_key="60d1d6c2411c435ead2de9a1ca352dd9"
openai.api_version ="2024-02-15-preview"
client = AzureOpenAI(
  azure_endpoint = "https://kaaropenaipoc1.openai.azure.com/", 
  api_key=openai.api_key,  
  api_version="2024-02-15-preview"
)

# query_engine = index.as_query_engine(llm = llm)



# cors = CORS(app)
# app.config['CORS_HEADERS'] = 'Content-Type'

class HelloWorldExample:

    def __init__(self, uri, user, password):
        self.driver = GraphDatabase.driver(uri, auth=(user, password))

    def close(self):
        self.driver.close()

    def print_greeting(self, message):
        with self.driver.session() as session:
            greeting = session.execute_write(self._create_and_return_greeting, message)
            print(greeting)

    @staticmethod
    def _create_and_return_greeting(tx, message):
        result = tx.run("CREATE (a:Greeting) "
                        "SET a.message = $message "
                        "RETURN a.message + ', from node ' + id(a)", message=message)
        return result.single()[0]
    @staticmethod
    def _get_services(tx,query):
        # result = tx.run("""MATCH p=(a:Application)<-[:uses]-(n:Service)-[r:stakeholder|sme]->(u:User) where toLower(u.name) contains "meena" return p""")
        result = tx.run(query)

        return result.data()
    

    def get_friends_of(self, name):
        with self.driver.session(database="hrss") as session:

            result = session.execute_read(self._get_services,name)
            # result = tx.run(query, name=name)
            print(result)
            for item in result:
                print(item)
            return result

def getQuery(inputChat):
    completion = client.chat.completions.create(
    model="kaadep", # model = "deployment_name"
    messages = inputChat,
    temperature=0.7,
    max_tokens=800,
    top_p=0.95,
    frequency_penalty=0,
    presence_penalty=0,
    stop=None)
    return completion.choices[0].message
prompt = """You are a neo4j expert, your job is to convert the layman queries into Cyper / neo4j query.  The schema of the nodes, node attributes, relationship & its attributes are presented below in "nodes and relations".   please convert the "Question" to "Cyper query" output .  Follow the instructions while generating the output  in "output format"    
   


output format : {"output": "query string"}    
    
Instructions :   
Please use the relationship only as per "Relations" . Use the from and to nodes only as per "Relations" 
if needed decompose the question into multiple sub questions and then construct the query    
Identify the nodes that needs to be part of the query and use only them    
Please use "contains" in the query for all string comparisons  
eg toLower(u.name) contains toLower("shah")    
Make the query case insensitive for all string comparisons  
      e.g. toLower(u.name) contains toLower("shah")    
user can be a SME or stakeholder for a service, use it when needed    
         [:sme|stakeholder]    
relationship's availablity_status has the following possible values    
  A-P : Already implemented    
  O-P : Opportunity available for implementation . Available for expansion   
  N-P : Not possible for implementation    
Please give the field names only from the details below, and not create new one. Pleaes use relationship attribute wherever needed    
verify the syntax and the check the output is in neo4j query format.    
Use nodes and relationships that are needed to address the question alone    
explicitly use WHERE clause for filtering the data.    
Use simple relations as possible and avoid complex queries.    
Try fixing spelling errors in the query
Use attributes from nodes and relationships only from the list below
Possible values for ChangeLog.change_type are addition and deletion
datetime parameters are year , month, date,   hour, minute ,second
convert the date to string output in the format "YYYY-MM-DD"

nodes and relations:     
  
Relations :
(Service)-[:sme]->(User)    
(Service)-[:stakeholder]->(User)    
(Service)-[:available_in]->(Country)    
(Service)-[:uses]->(Application)       
(Service)-[:has_process]->(Process)
(Service)-[:part_of]->(ChangeLog)

Relationship attributes:
[:available_in].availablity_status  to represent the status of the service in the company.


Nodes:    
Service    
User    
Country    
Application 
Process
ChangeLog

Attributes    
service.name    
service.automation_name    
service.botid    
service.fte_count
change.description
change.id
change.sign_off_date
change.change_type
change.id = service.id
Examples : 
ex question :  if Rajni is being replaced by vijay, identify the services impacted.
Output : {"output": "match k=(s:Service)-[p:sme|stakeholder]-(u) where toLower(u.name) contains "Rajni" or toLower(u.name) contains "vijay" return k"}

ex question : Get all applications used in cardiology service
match k=(s:Service)-[:uses]-(app)  where toLower(s.name) contains "cardiology"   return distinct(app.name)

ex question:  Get all services handled by Dr. Meena
Output : match (u:User)<-[:sme|stakeholder]-(s.Service) where toLower(u.name) contains "meena" RETURN s.name

ex question:  Get all services added in 2024.
Output :  MATCH (c:ChangeLog) WHERE toLower(c.change_type) contains toLower("addition") and c.sign_off_date > datetime({year:2024})   RETURN DISTINCT c.description,c.id,c.change_type


ex question:  Get all the countries for cardiology where it is already expanded.
Output : match MATCH (s:Service)-[k:available_in]-(c:Country) WHERE toLower(s.name) CONTAINS toLower('interventional cardiology') and k.availablity_status="A-P" RETURN DISTINCT c.name

Question : """


def getResponse(inputChat):
    completion = client.chat.completions.create(
    model="kaadep", # model = "deployment_name"
    messages = inputChat,
    temperature=0.7,
    max_tokens=800,
    top_p=0.95,
    frequency_penalty=0,
    presence_penalty=0,
    stop=None)
    return completion.choices[0].message
    # Please reword or format the answers in "context" to match the tone of the  "question". 

prompt1 = """
    The "Context" is the output of Neo4j Query. 
    Dont use new . 
    Pleaese use teh "context" to format the answer to match the tone of the question, please format the context and give it as answer.
    Structure the output as bullet points or  tables whenever a comparison is made.

    Notes: 
    relationship's availablity_status has the following possible values    
  A-P : Already implemented    
  O-P : Opportunity available for implementation . Available for expansion   
  N-P : Not possible for implementation    

Question : QUESTION_HOLDER

Context : """


@app.route('/api/conversation',methods=['POST',"GET"])
def hello(req: func.HttpRequest) -> func.HttpResponse:
    # data=request.data
    data = req.get_json() 
    print(data)
    temp = [ {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": prompt+data['messages'][0]['content']}]
    query = getQuery(temp)
    print(query)
    json_data = json.loads(query.content)
    # res = get_friends_of()
    greeter = HelloWorldExample("bolt://localhost:7687", "hrss", "neo4j")
    reout = greeter.get_friends_of(json_data['output'])
    result = {}
    result['id']="request.json['id']"
    result['model']="sss"
    result['created']="sss"
    choices = []
    choice = {}
    messages=[]
    # message = {}
    # message['role']="tool"
    # message['content']="Hello, World!"
    # messages.append(message)
    message = {}
    message['role']="assistant"
    message['content']="Hello, World!"
    for item in reout:
        message['content'] = message['content'] + str(item)

    # message['content']=""+reout+""
    # prompt1
    temp1 = [ {"role": "system", "content": "You are a helpful assistant."},
    {"role": "user", "content": prompt1.replace("QUESTION_HOLDER",data['messages'][0]['content'])+message['content'] }]
    response1 = getResponse(temp1)
    print(response1)
    message['content']=response1.content


    messages.append(message)
    choice['messages']=messages
    choices.append(choice)
    result['choices']=choices
    # return jsonify(result)
    return func.HttpResponse(json.dumps(result),mimetype="application/json")

# @app.route('/sss')
# def number():
#     return jsonify(number=42)


