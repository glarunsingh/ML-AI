import azure.functions as func

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

from neo4j import GraphDatabase
import json
import openai
from openai import AzureOpenAI
from langchain.embeddings.azure_openai import AzureOpenAIEmbeddings
from langchain.vectorstores.neo4j_vector import Neo4jVector
from langchain.docstore.document import Document
import os
import logging
from datetime import datetime
import pymongo

openai.api_key="60d1d6c2411c435ead2de9a1ca352dd9"
openai.api_version ="2024-02-15-preview"
embedding_model_name = "travel-ada"

client = AzureOpenAI(
  azure_endpoint = "https://kaaropenaipoc1.openai.azure.com/", 
  api_key=openai.api_key,  
  api_version="2024-02-15-preview"
)

embeddingclient = AzureOpenAI(
    azure_deployment=embedding_model_name,
    api_version="2023-12-01-preview",
    azure_endpoint="https://travel-openai.openai.azure.com/",
    api_key="01995a8ce3a34cfdb92c7033af10b24d"
    # ,azure_ad_token_provider=token_provider if not AZURE_OPENAI_KEY else None
)

os.environ["AZURE_OPENAI_API_KEY"] = "62855d6dd08945819bf83aee0c104127"

embed_model = AzureOpenAIEmbeddings(
    
        model="text-embedding-ada-002",
        azure_deployment="dskumar-text-embedding-ada-002",
        azure_endpoint="https://dskumar.openai.azure.com/",
        openai_api_version="2023-08-01-preview",
)

URI = "neo4j+ssc://b2fbd319.databases.neo4j.io:7687"
NEO4J_USERNAME  = "neo4j"
NEO4J_PASSWORD = "_YJCyoiObUQ3I_zUONJY9zMC9XEEoD5DyUL4IciUtL0"


connection_string = 'mongodb+srv://analysis:Vector-dbstore@vectordbstore.mongocluster.cosmos.azure.com/?tls=true&authMechanism=SCRAM-SHA-256&retrywrites=false&maxIdleTimeMS=120000'
mongodb_client = pymongo.MongoClient(connection_string)
db = mongodb_client["TravelandExpense"] 
Querycollection =db["HRSS"]
# query_engine = index.as_query_engine(llm = llm)



# cors = CORS(app)
# app.config['CORS_HEADERS'] = 'Content-Type'

class HelloWorldExample:

    def __init__(self, uri, user, password):
        uri = "neo4j+ssc://b2fbd319.databases.neo4j.io:7687"
        self.driver = GraphDatabase.driver(uri, auth=("neo4j", "_YJCyoiObUQ3I_zUONJY9zMC9XEEoD5DyUL4IciUtL0"))

    def close(self):
        self.driver.close()

    def print_greeting(self, message):
        with self.driver.session() as session:
            greeting = session.execute_write(self._create_and_return_greeting, message)
            # print(greeting)

    @staticmethod
    def _create_and_return_greeting(tx, message):
        result = tx.run("CREATE (a:Greeting) "
                        "SET a.message = $message "
                        "RETURN a.message + ', from node ' + id(a)", message=message)
        return result.single()[0]
    @staticmethod
    def _get_services(tx,query):
        # result = tx.run("""MATCH p=(a:Application)<-[:uses]-(n:Service)-[r:stakeholder|sme]->(u:User) where toLower(u.name) contains "meena" return p""")
        result = tx.run(query)

        return result.data()
    

    def get_friends_of(self, name):
        with self.driver.session(database="neo4j") as session:

            result = session.execute_read(self._get_services,name)
            # result = tx.run(query, name=name)
            print(result)
            # for item in result:
            #     print(item)
            return result

def getQuery(inputChat):
    completion = client.chat.completions.create(
    model="kaadep", # model = "deployment_name"
    messages = inputChat,
    temperature=0.7,
    max_tokens=800,
    seed =42,
    top_p=0.95,
    frequency_penalty=0,
    presence_penalty=0,
    stop=None)
    return completion.choices[0].message
prompt = """You are a neo4j expert, your job is to convert the layman queries into Cyper / neo4j query.  The schema of the nodes, node attributes, relationship & its attributes are presented below in "nodes and relations".   please convert the "Question" to "Cyper query" output .  Follow the instructions while generating the output  in "output format"    
   


output format : {"output": "query string"}    
    
Instructions :   
Please use the relationship only as per "Relations" . Use the from and to nodes only as per "Relations" 
if needed decompose the question into multiple sub questions and then construct the query    
Identify the nodes that needs to be part of the query and use only them    
Please use "contains" in the query for all string comparisons  
eg toLower(u.name) contains toLower("shah")    
Make the query case insensitive for all string comparisons  
      e.g. toLower(u.name) contains toLower("shah")    
user can be a SME or stakeholder for a service, use it when needed    
         [:sme|stakeholder]    
relationship's availablity_status has the following possible values    
  A-P : Already implemented    
  O-P : Opportunity available for implementation . Available for expansion   
  N-P : Not possible for implementation    
Please give the field names only from the details below, and not create new one. Pleaes use relationship attribute wherever needed    
verify the syntax and the check the output is in neo4j query format.    
Use nodes and relationships that are needed to address the question alone    
explicitly use WHERE clause for filtering the data.    
Use simple relations as possible and avoid complex queries.    
Try fixing spelling errors in the query
Use attributes from nodes and relationships only from the list below
Possible values for ChangeLog.change_type are addition and deletion
datetime parameters are year , month, date,   hour, minute ,second
convert the date to string output in the format "YYYY-MM-DD"

nodes and relations:     
  
Relations :
(Service)-[:sme]->(User)    
(Service)-[:stakeholder]->(User)    
(Service)-[:available_in]->(Country)    
(Service)-[:uses]->(Application)       
(Service)-[:has_process]->(Process)
(Service)-[:part_of]->(ChangeLog)

Relationship attributes:
[:available_in].availablity_status  to represent the status of the service in the company.


Nodes:    
Service    
User    
Country    
Application 
Process
ChangeLog

Attributes    
service.name    
service.automation_name    
service.botid    
service.fte_count
change.description
change.id
change.sign_off_date
change.change_type
change.id = service.id
Examples : 
ex question :  if Rajni is being replaced by vijay, identify the services impacted.
Output : {"output": "match k=(s:Service)-[p:sme|stakeholder]-(u) where toLower(u.name) contains "Rajni" or toLower(u.name) contains "vijay" return k"}

ex question : Get all applications used in cardiology service
match k=(s:Service)-[:uses]-(app)  where toLower(s.name) contains "cardiology"   return distinct(app.name)

ex question:  Get all services handled by Dr. Meena
Output : match (u:User)<-[:sme|stakeholder]-(s.Service) where toLower(u.name) contains "meena" RETURN s.name

ex question:  Get all services added in 2024.
Output :  MATCH (c:ChangeLog) WHERE toLower(c.change_type) contains toLower("addition") and c.sign_off_date > datetime({year:2024})   RETURN DISTINCT c.description,c.id,c.change_type


ex question:  Get all the countries for cardiology where it is already expanded.
Output : match MATCH (s:Service)-[k:available_in]-(c:Country) WHERE toLower(s.name) CONTAINS toLower('interventional cardiology') and k.availablity_status="A-P" RETURN DISTINCT c.name

Question : """


def getResponse(inputChat):
    completion = client.chat.completions.create(
    model="kaadep", # model = "deployment_name"
    messages = inputChat,
    temperature=0.7,
    max_tokens=800,
    seed =42,
    top_p=0.95,
    frequency_penalty=0,
    presence_penalty=0,
    stop=None)
    return completion.choices[0].message
    # Please reword or format the answers in "context" to match the tone of the  "question". 

prompt1 = """
    The "Context" is the output of Neo4j Query. 
    Dont use new . 
    Pleaese use teh "context" to format the answer to match the tone of the question, please format the context and give it as answer.
    Structure the output as bullet points or  tables whenever a comparison is made.

    Notes: 
    relationship's availablity_status has the following possible values    
  A-P : Already implemented    
  O-P : Opportunity available for implementation . Available for expansion   
  N-P : Not possible for implementation    

Question : QUESTION_HOLDER

Context : """

def getsearchresult(searchquery):
    existing_index_return = Neo4jVector.from_existing_index(
    embed_model,
    url=URI,
    username=NEO4J_USERNAME,
    password=NEO4J_PASSWORD,
    database="neo4j",  # neo4j by default
    index_name="vector",  # vector by default
    node_label="Chunk",  # Chunk by default
    text_node_property="text",  # text by default
    embedding_node_property="vector",  # embedding by default
    )

    result = existing_index_return.similarity_search_with_score(searchquery, k=1)
    print(result)
    # print(result[0][1])

    if len(result) > 0 and result[0][1] >= 0.98:
        return result[0][0]
    else:
        return 

def generate_embeddings(query):
    '''
    Generate embeddings from string of text.
    This will be used to vectorize data and user input for interactions with Azure OpenAI.
    '''
    return embeddingclient.embeddings.create(input=query, model=embedding_model_name).data[0].embedding


def savequery(input,searchquery,result):
    try:
        query_embedding = generate_embeddings(input)   

        # savequery          
        response_obj = {
                "Empid": '',                           
                "Query": input,
                "QueryVector" : query_embedding,
                "Searchquery":searchquery,
                "Content": result,                
                "ThumbsUp/Down": 1,
                "Datetime":datetime.now()
                }  
        insertquery(response_obj)
    except Exception as e:
        logging.exception("Exception while saving query")
        raise e

# Simple function to assist with vector search
def vector_search(query_embedding, num_results=5):
    
    embeddings_list = []
    pipeline = [
        {
            '$search': {
                "cosmosSearch": {
                    "vector": query_embedding,
                    "path": "QueryVector",
                    "k": num_results#, #, "efsearch": 40 # optional for HNSW only 
                    #"filter": {"title": {"$ne": "Azure Cosmos DB"}}
                },
                "returnStoredSource": True }},
        {'$project': { 'similarityScore': { '$meta': 'searchScore' }, 'document' : '$$ROOT' } }
    ]
    results = Querycollection.aggregate(pipeline)
    return results

def insertquery(request_body):
    try:  
        query ={}
        query = request_body                       
        queryexists = Querycollection.find_one(query)                        
        if queryexists:
            response = 'Query already exists'
        else:
            Querycollection.insert_one(request_body)
            response = 'Query inserted successfully'
        # return response
    except Exception as error:
        logging.exception("Exception while adding Query", error)

@app.route('getqueries',methods=['POST',"GET"])
def get_queries(req: func.HttpRequest) -> func.HttpResponse:
    try:
        data = req.get_json()
        print(data)
       
        input = data['messages'][0]['content']

        query_embedding = generate_embeddings(input)
        results = vector_search(query_embedding)
        response =[]
        for result in results: 
            if result['document']['ThumbsUp/Down'] ==1:
                response.append(result['document']['Query'])
                # print(f"Similarity Score: {result['similarityScore']}")  
                # print(f"Title: {result['document']['title']}")  
                # print(f"Content: {result['document']['content']}")  
                # print(f"Category: {result['document']['category']}\n") 

        unique_queries = []
 
        # traverse for all elements
        for x in response:
        # check if exists in unique_list or not
            if x not in unique_queries:
                unique_queries.append(x)       
        return func.HttpResponse(json.dumps(unique_queries),mimetype="application/json")
    
    except Exception as e:
        logging.exception("Exception in getqueries")
        return func.HttpResponse(json.dumps({"error": str(e)}), 500)
   
@app.route('getreftext',methods=['POST',"GET"])
def reftext(req: func.HttpRequest) -> func.HttpResponse:
    try:
        data=req.params.get('reftext')    
        greeter = HelloWorldExample("bolt://localhost:7687", "neo4j", "neo4j")
        result = greeter.get_friends_of("""call db.index.fulltext.queryNodes("hrindex","*"""+data+"""*") YIELD node, score
        RETURN node.name as Reftext, labels(node) as Group, score """)
    # messages=[]
    # message={}
    # for item in reout:
    #     # print(item["node.name"])
    #     message["text"] =  item["node.name"]        
    #     message["Group"] = item["labels(node)"]         
    #     messages.append(message)
        
        return func.HttpResponse(json.dumps(result),mimetype="application/json")
    except Exception as e:
        logging.exception("Exception in /getreftext ", e)
        return func.HttpResponse(json.dumps({"error": str(e)}), 500)

@app.route('conversation',methods=['POST',"GET"])
def hello(req: func.HttpRequest) -> func.HttpResponse:
    # data=request.data
    try:
        data = req.get_json() 
        print(data)
        cache = 'False'
        input = data['messages'][0]['content']
        result = getsearchresult(input)
        if result is None:
            temp = [ {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": prompt+data['messages'][0]['content']}]
            query = getQuery(temp)
            # print(query)
            json_data = json.loads(query.content)
            searchquery = json_data['output']
            # print(searchquery)
            cache='True'
        else:    
            json_data =result.metadata
            json_data =json_data["answer"]
            # print(json_data)
            searchquery = json.loads(json_data)['output']
        #     print(searchquery)

        result = {}
        result['id']="request.json['id']"
        result['model']="sss"
        result['created']="sss"
        message = {}
        message['role']="assistant"
        choices = []
        choice = {}
        messages=[]
        message['content']="Hello, World!"
        
        if 'MATCH' in searchquery:
            greeter = HelloWorldExample("bolt://localhost:7687", "neo4j", "neo4j")
            reout = greeter.get_friends_of(searchquery)
            print(reout)      
            for item in reout:
                message['content'] = message['content'] + str(item)
            print(message['content'])
        if message['content'] != "Hello, World!" and cache =='True':
            doc =  Document(page_content=data['messages'][0]['content'] , metadata={"answer": """{"output":" """ +searchquery+""" "}"""})
            print(doc)
            neo4j_db = Neo4jVector.from_documents(
                [doc],
                embed_model,
                url=URI,
                username=NEO4J_USERNAME,
                password=NEO4J_PASSWORD,
                database="neo4j",  # neo4j by default
                index_name="vector",  # vector by default
                node_label="Chunk",  # Chunk by default
                text_node_property="text",  # text by default
                embedding_node_property="vector",  # embedding by default
                create_id_index=True,  # True by default
                )

        # message['content']=""+reout+""
        # prompt1
        if message['content'] != "Hello, World!":
            temp1 = [ {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt1.replace("QUESTION_HOLDER",data['messages'][0]['content'])+message['content'] }]
            response = getResponse(temp1)
            print(response)
            message['content']=response.content
        else:
            message['content']='How can I assist you today?'

        messages.append(message)
        choice['messages']=messages
        choices.append(choice)
        result['choices']=choices
        # return jsonify(result)
        savequery(input,searchquery,message['content']) 
        return func.HttpResponse(json.dumps(result),mimetype="application/json")
    except Exception as e:
        logging.exception("Exception in /hello ", e)
        return func.HttpResponse(json.dumps({"error": str(e)}), 500)
# @app.route('/sss')
# def number():
#     return jsonify(number=42)


