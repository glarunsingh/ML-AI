import azure.functions as func

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

@app.route(route="FinanceAnalyzer")
def FinanceAnalyzer(req: func.HttpRequest) -> func.HttpResponse:
    import logging
    import json    
    import random
    import pandas as pd
    import os
    import openai 
    from llama_index.query_engine import SubQuestionQueryEngine
    from llama_index.tools import QueryEngineTool, ToolMetadata
    from llama_index import VectorStoreIndex, SimpleDirectoryReader,ServiceContext
    from llama_index.callbacks import CallbackManager, LlamaDebugHandler
    from llama_index.llms import AzureOpenAI
    from llama_index.agent import ReActAgent
    from llama_index.llms import OpenAI
    from llama_index.embeddings import AzureOpenAIEmbedding
    from llama_index.indices.vector_store.base import VectorStoreIndex
    from llama_index import StorageContext
    from llama_index import set_global_service_context
    from llama_index.readers.file.base import SimpleDirectoryReader
    from llama_index.vector_stores.azurecosmosmongo import (
        AzureCosmosDBMongoDBVectorSearch,
    )
    import pymongo

    logging.info('Python HTTP trigger function processed a request.')

    os.environ["OPENAI_API_KEY"] = "62855d6dd08945819bf83aee0c104127"
    openai.api_key="62855d6dd08945819bf83aee0c104127"
    openai.api_version = "2023-07-01-preview"

# Set up the AzureOpenAI instance
    llm = AzureOpenAI(
        azure_endpoint="https://dskumar.openai.azure.com/",
        api_version=openai.api_version,
        api_key=openai.api_key,
        engine="DskumarDeployment", 
        model="gpt-35-turbo-16k", 
        temperature=0.0,
    )


# Set up the OpenAIEmbedding instance
    embed_model = AzureOpenAIEmbedding(
        model="text-embedding-ada-002",
        deployment_name="dskumar-text-embedding-ada-002",
        api_key=openai.api_key,
        azure_endpoint="https://dskumar.openai.azure.com/",
        api_version="2023-07-01-preview",
    )

    service_context = ServiceContext.from_defaults(
        llm=llm, embed_model=embed_model
    )

    set_global_service_context(service_context)

    df = pd.read_csv('summary.csv')
    df.head()
    companies = " for "
    company1=[]
    
    reporttype = req.params.get('reporttype')
    input = req.params.get('input')
    #company1 = ['Microsoft','Alphabet Inc.']
    company1  = req.params.get('company1').split(',')
    print(company1)
    symbol = []
    for company in company1:
        symbol.append(df[df['company-name'] == company]['trading-symbol'].values[0])
    print(symbol)

    doctypes = df[df['trading-symbol'].isin( symbol)]['document-type'].unique().tolist()
    
    #reporttype ='10K'
        
    llama_debug = LlamaDebugHandler(print_trace_on_end=True)
    callback_manager = CallbackManager([llama_debug])
    
    print(df)
    df = df[(df['trading-symbol'].isin( symbol))  ]
       
    print(df)
       
    print("symbol**************",symbol)
    print("reporttype**************",reporttype)

    query_engine_tools = [ ]
    for filename in df['filename'].values:
        print("********** loading filename ",filename," ***********************")
        #name1, index, engine = get_vector_index("", "",filename)
        connection_string = 'mongodb+srv://analysis:Vector-dbstore@vectordbstore.mongocluster.cosmos.azure.com/?tls=true&authMechanism=SCRAM-SHA-256&retrywrites=false&maxIdleTimeMS=120000'
        mongodb_client = pymongo.MongoClient(connection_string)
        store = AzureCosmosDBMongoDBVectorSearch(
        mongodb_client=mongodb_client,
        db_name="financeanalysis",
        collection_name=filename    
        )

        client_index = VectorStoreIndex.from_vector_store(vector_store=store,
                                                          service_context=service_context)
    

        client_engine = client_index.as_query_engine(similarity_top_k=3)

        df1= df[df['filename']==filename]
        companies+=df1['company-name'].values[0]+" , "
        print(df1)
        #print("Description : ","{} document for {}".format(
                        #df1['document-type'].values[0], df1['company-name'].values[0]))
        #print("name= ",df1['filename'].values[0].replace(","," "))
        query_engine_tools.append(
            QueryEngineTool(
                query_engine=client_engine,
                metadata=ToolMetadata(
                    name=df1['filename'].values[0],
                    description="{} document for {}".format(
                        df1['document-type'].values[0], df1['company-name'].values[0])
                    ),
                )
        ),
    print("companies*************",companies)
   
    os.environ["OPENAI_API_KEY"] = "62855d6dd08945819bf83aee0c104127"
    openai.api_key="62855d6dd08945819bf83aee0c104127"
    openai.api_version = "2023-07-01-preview"
        

    llm1=  AzureOpenAI(azure_endpoint="https://dskumar.openai.azure.com/",api_version=openai.api_version,
        engine="DskumarDeployment", model="gpt-35-turbo-16k", temperature=0.0,
        )
        
    agent = ReActAgent.from_tools(query_engine_tools, llm=llm1, verbose=True)
    print(agent)
       

# Accept user input
    #input ='What is the total income?'
    prompt = input
    
    full_response = ""
    print(prompt)
    if prompt:
        assistant_reponse = prompt + companies +" Please provide the output as numbered list"
    else:
        assistant_reponse = random.choice(
            [
                "Hello there! How can I assist you today?",
                "Hi, human! Is there anything I can help you with?",
                "Do you need help?",
            ]
        )
    
    print(assistant_reponse)
    full_response = agent.query(assistant_reponse)  
    print(full_response.response)
    output = {"Output":full_response.response}
    return func.HttpResponse(
        json.dumps(output),
        mimetype="application/json",
    )
    #return func.HttpResponse(jsonify(full_response.response))

    #name = req.params.get('name')
    #if not name:
        #try:
            #req_body = req.get_json()
        #except ValueError:
            #pass
        #else:
            #name = req_body.get('name')

    #if name:
        #return func.HttpResponse(f"Hello, {name}. This HTTP triggered Azure function executed successfully. Thanks")
    #else:
        #return func.HttpResponse(
            # "This HTTP triggered function executed successfully. Pass a name in the query string or in the request body for a personalized response.",
            # status_code=200
        #)