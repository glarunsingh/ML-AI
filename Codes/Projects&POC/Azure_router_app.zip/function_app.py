import azure.functions as func
import logging

app = func.FunctionApp(http_auth_level=func.AuthLevel.ANONYMOUS)

import os
import logging
import json
from typing import Literal
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.pydantic_v1 import BaseModel, Field
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from langchain_core.prompts import ChatPromptTemplate
from langchain.utils.math import cosine_similarity
import requests
 
# Setting Environment variable
os.environ["AZURE_OPENAI_API_VERSION"] = "2023-07-01-preview"
os.environ["AZURE_OPENAI_ENDPOINT"] = 'https://dskumar.openai.azure.com/'
os.environ["AZURE_OPENAI_API_KEY"] = "62855d6dd08945819bf83aee0c104127"
os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"] = "DskumarDeployment"
os.environ['OPENAI_TYPE'] = "Azure"
os.environ["LLM_MODEL"] = "gpt-35-turbo-16k"
os.environ["LLM_EMBEDDING_MODEL"] = "dskumar-text-embedding-ada-002"
 
## Azure chatmodel
azurechatmodel = AzureChatOpenAI(
    openai_api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    azure_deployment=os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"],temperature=0, max_tokens=150
)


##Azure embedding
embeddings = AzureOpenAIEmbeddings(model=os.environ["LLM_EMBEDDING_MODEL"])

#URL
URL_Travel_Expenses = "https://travelexpenses.azurewebsites.net/api/conversation"
URL_Medical_Service = "https://hrss.azurewebsites.net/api/conversation"
 

@app.route(route="http_router")
def http_Router(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python http_router processed a request.')
 
    req_body = req.get_json() ### It is in dict format - Python object
 
    # Extract messages
    messages = req_body.get('messages', [])
 
    # Extract content from each message
    for message in messages:
        query = message.get('content', '')
        RouterType = message.get('RouterType','')
 
    
    if RouterType == "Logical":
        url = process_query_logically(query)
    elif RouterType == "Semantic":
        url = process_query_Semantic(query)
        
    # Convert the payload to JSON format
    # Convert Python object into a JSON string.
    json_payload = json.dumps(req_body)
    response = requests.post(url=url,data=json_payload)#JSON string.
    return func.HttpResponse (response.text,status_code=response.status_code)
 
def process_query_logically(query):
    
        class RouteQuery(BaseModel):
            """Route a user query to the most relevant datasource."""
            datasource: Literal["Travel_Expense_process_policy_docs", "Medical_Service_Catalogue"] = Field(
            ..., description="Given a user question choose which datasource would be most relevant for answering their question",
            )
 
        structured_llm = azurechatmodel.with_structured_output(RouteQuery)
 
        system = """You are an expert at routing a user question to the appropriate data source.
        Based on the document type the question is referring to, route it to the relevant data source."""
 
        logical_prompt = ChatPromptTemplate.from_messages(
        [
        ("system", system),
        ("human", "{question}"),
        ])
        # Define routers
        logical_router = logical_prompt | structured_llm
 
        result = logical_router.invoke({"question": query})
        logging.info(result.datasource)

        URL=""
        if "Travel_Expense_process_policy_docs" in result.datasource:
            logging.info("Logical - Using Travel Expense")
            URL = URL_Travel_Expenses
        elif "Medical_Service_Catalogue" in result.datasource:
             logging.info("Logical - Using medical service")
             URL = URL_Medical_Service
        return URL
       
def process_query_Semantic(query):
     
      
    # Two prompts
    travel_expense_template = """You are a highly knowledgeable/travel expense coordinator. \ 
    You excel at managing and analyzing travel expenses, and you provide clear, concise, and easy-to-understand answers regarding travel 
    and expense reports. \You are so good because you are able to break down hard problems
    into their component parts, \ answer the component parts, and then put them together to answer the broader question.
    """

    medical_service_template = """You excel at managing hospital services and medical processes. \ 
        You are adept at answering questions related to medical service catalogue management. \ You are highly skilled because \ you can break down complex medical and hospital-related issues into their 
        component parts, address each part individually,and then combine them to provide a comprehensive answer to the broader question.
        """

    prompt_templates = [travel_expense_template, medical_service_template]

    #Embed prompts
    prompt_embeddings = embeddings.embed_documents(prompt_templates)

    # Embed question
    query_embedding = embeddings.embed_query(query)

    # Compute similarity 
    similarity = cosine_similarity([query_embedding], prompt_embeddings)[0]
    most_similar_index = similarity.argmax()

    # Chosen prompt 
    chosen_route = prompt_templates[most_similar_index]

    URL=""
    if chosen_route == travel_expense_template:
        logging.info("Semantic - Using Travel Expense")
        URL = URL_Travel_Expenses
    elif chosen_route == medical_service_template:
        logging.info("Semantic- Using medical service")
        URL = URL_Medical_Service
    return URL

   



 
 
   
         
 
           
 
     
 
   
 
   
 
 